package com.example.food_recommender

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
