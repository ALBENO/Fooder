class Parameters {
  String type;
  double minPrice;
  double maxPrice;
  String flavour;

  Parameters({required this.type, required this.minPrice, required this.maxPrice, required this.flavour});
}
