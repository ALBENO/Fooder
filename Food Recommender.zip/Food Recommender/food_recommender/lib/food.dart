class Food {
  String foodName;
  double price;
  String flavor;
  double rating;
  String type;

  Food(
      {required this.foodName,
      required this.price,
      required this.flavor,
      required this.rating,
      required this.type});
}
